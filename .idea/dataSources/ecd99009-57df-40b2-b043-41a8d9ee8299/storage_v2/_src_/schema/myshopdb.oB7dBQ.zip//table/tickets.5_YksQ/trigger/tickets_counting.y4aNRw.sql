create trigger tickets_counting
  before INSERT
  on tickets
  for each row
  BEGIN
	UPDATE festivals SET free_tickets = free_tickets - 1 WHERE NEW.festival_id = id;
END;

