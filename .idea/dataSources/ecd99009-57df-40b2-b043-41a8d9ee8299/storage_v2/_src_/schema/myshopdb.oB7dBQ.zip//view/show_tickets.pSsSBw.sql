create view show_tickets as
  select `myshopdb`.`tickets`.`id`                                                  AS `id`,
         (select `myshopdb`.`clients`.`name`
          from `myshopdb`.`clients`
          where (`myshopdb`.`clients`.`id` = `myshopdb`.`tickets`.`client_id`))     AS `client`,
         (select `myshopdb`.`festivals`.`name`
          from `myshopdb`.`festivals`
          where (`myshopdb`.`festivals`.`id` = `myshopdb`.`tickets`.`festival_id`)) AS `festival`
  from `myshopdb`.`tickets`;

