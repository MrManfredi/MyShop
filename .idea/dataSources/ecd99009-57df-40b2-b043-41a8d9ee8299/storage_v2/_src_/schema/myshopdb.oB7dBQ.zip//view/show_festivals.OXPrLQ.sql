create view show_festivals as
  select `myshopdb`.`festivals`.`id`       AS `id`,
         `myshopdb`.`festivals`.`place_id` AS `place_id`,
         `myshopdb`.`festivals`.`name`     AS `name`,
         `myshopdb`.`festivals`.`date`     AS `date`,
         `myshopdb`.`festivals`.`price`    AS `price`
  from `myshopdb`.`festivals`;

