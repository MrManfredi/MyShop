create trigger tickets_counting2
  before DELETE
  on tickets
  for each row
  BEGIN
	UPDATE festivals SET free_tickets = free_tickets + 1 WHERE OLD.festival_id = id;
END;

