create trigger delete_client
  before DELETE
  on clients
  for each row
  BEGIN
   DELETE FROM tickets WHERE client_id = OLD.id;
END;

